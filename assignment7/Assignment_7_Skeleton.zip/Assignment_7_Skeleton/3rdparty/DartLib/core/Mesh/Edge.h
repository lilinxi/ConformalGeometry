#ifndef _DARTLIB_EDGE_H_
#define _DARTLIB_EDGE_H_

#include "Cell.h"

namespace DartLib
{

template <int N>
class TEdge : public TCell< N >
{
  public:
    TEdge() {};

  protected:
};


}
#endif // !_DARTLIB_EDGE_H_
