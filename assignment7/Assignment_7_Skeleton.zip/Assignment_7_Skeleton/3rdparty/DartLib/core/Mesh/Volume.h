#ifndef _DARTLIB_VOLUME_H_
#define _DARTLIB_VOLUME_H_

#include "Cell.h"

namespace DartLib
{

template <int N>
class TVolume : public TCell< N >
{
  public:
    TVolume() {};

  protected:
    
};


}
#endif // !_DARTLIB_VOLUME_H_
