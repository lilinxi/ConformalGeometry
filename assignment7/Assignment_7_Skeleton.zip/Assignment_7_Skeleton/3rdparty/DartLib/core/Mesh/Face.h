#ifndef _DARTLIB_FACE_H_
#define _DARTLIB_FACE_H_

#include "Cell.h"

namespace DartLib
{

template <int N>
class TFace : public TCell< N >
{
  public:
    TFace() {};

  protected:
};


}
#endif // !_DARTLIB_FACE_H_
