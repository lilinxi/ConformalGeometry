# Computational Conformal Geometry Homework

This C++ project framework is used to help students to implement geometric algorithms.

## System

The code has been tested on Windows 10, Ubuntu 18.04, if there is any problem, please let me know.

## Directory Structure

``` txt
KoebeIteration      -- Folder for Koebe iteration algorithm.
data                -- Some models.
textures            -- Some texture images.
CMakeLists.txt      -- CMake configuration file.
resources           -- Some resources needed.
3rdparty            -- MeshLib, freeglut, Eigen libraries.
```

## Configuration

Follow the instruction in the README.md of each algorithm folder.
